package MGame;

// Modified MazeGame class using Prototype Pattern
public class MazeGame {
    public static void main(String[] argv) {
        createMaze();
    }

    private static Maze createMaze() {
        MazePrototypeFactory factory = new MazePrototypeFactory();

        // Register prototypes
        factory.registerRoom("room", new Room(0));
        factory.registerWall("wall", new Wall());
        factory.registerWall("door", new DoorWall(null, null)); // Initial prototypes can be null for door

        // Create rooms and walls using prototypes
        Maze aMaze = new Maze();
        Room r1 = factory.makeRoom("room");
        Room r2 = factory.makeRoom("room");
        DoorWall d = (DoorWall) factory.makeWall("door");

        // Add rooms to the maze
        aMaze.addRoom(r1);
        aMaze.addRoom(r2);

        // Set sides for each room
        r1.setSide(Direction.NORTH, d);
        r1.setSide(Direction.EAST, factory.makeWall("wall"));
        r1.setSide(Direction.SOUTH, factory.makeWall("wall"));
        r1.setSide(Direction.WEST, factory.makeWall("wall"));
        r2.setSide(Direction.NORTH, factory.makeWall("wall"));
        r2.setSide(Direction.EAST, factory.makeWall("wall"));
        r2.setSide(Direction.SOUTH, d);
        r2.setSide(Direction.WEST, factory.makeWall("wall"));

        return aMaze;
    }
}

