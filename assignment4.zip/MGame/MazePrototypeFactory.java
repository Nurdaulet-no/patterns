package MGame;

import java.util.HashMap;
import java.util.Map;

// MazePrototypeFactory class to manage prototypes
public class MazePrototypeFactory {
    private Map<String, Room> roomPrototypes = new HashMap<>();
    private Map<String, Wall> wallPrototypes = new HashMap<>();

    // Register room prototype
    public void registerRoom(String type, Room room) {
        roomPrototypes.put(type, room);
    }

    // Register wall prototype
    public void registerWall(String type, Wall wall) {
        wallPrototypes.put(type, wall);
    }

    // Clone room prototype
    public Room makeRoom(String type) {
        Room room = roomPrototypes.get(type);
        if (room != null) {
            try {
                return (Room) room.clone();
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    // Clone wall prototype
    public Wall makeWall(String type) {
        Wall wall = wallPrototypes.get(type);
        if (wall != null) {
            try {
                return (Wall) wall.clone();
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
