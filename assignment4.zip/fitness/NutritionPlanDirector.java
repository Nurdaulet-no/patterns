package fitness;

import java.util.Arrays;

public class NutritionPlanDirector {
    private NutritionPlanBuilder builder;

    public void setBuilder(NutritionPlanBuilder builder) {
        this.builder = builder;
    }

    public NutritionPlan createNutritionPlan() {
        builder.setCaloricIntake(2000);
        builder.setMacronutrientRatios(50, 30, 20);
        builder.setMealPlans(Arrays.asList("Breakfast", "Lunch", "Dinner"));
        builder.setFitnessGoal("Weight Loss");
        builder.setDietaryRestrictions(Arrays.asList("Vegan"));

        return builder.build();
    }
}
