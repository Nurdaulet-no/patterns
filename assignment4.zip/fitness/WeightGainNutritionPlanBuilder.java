package fitness;

import java.util.ArrayList;
import java.util.List;

public class WeightGainNutritionPlanBuilder extends NutritionPlanBuilder{
    public WeightGainNutritionPlanBuilder(){
        this.nutritionPlan = new NutritionPlan();
    }
    @Override
    public void setCaloricIntake(int caloricIntake) {
        int weightGainCalories = caloricIntake + 800;
        nutritionPlan.setDailyCaloricIntake(weightGainCalories);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        int newCarbohydrates = 70;
        int newProteins = 90;
        int newFats = 30;
        nutritionPlan.setMacronutrientRatios(new int[]{newCarbohydrates, newProteins, newFats});
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        List<String> newMealPlans = new ArrayList<>();
        newMealPlans.add("High-calorie, nutrient-dense meals\n");
        newMealPlans.add("Incorporate healthy fats like olive oil, nuts, and avocados\n");
        newMealPlans.add("Include complex carbohydrates such as whole grains and starchy vegetables\n");
        newMealPlans.add("Consume protein-rich foods like lean meats, poultry, fish, and dairy products\n");
        newMealPlans.add("Have frequent meals and snacks throughout the day to increase calorie intake\n");
        nutritionPlan.setMealPlans(newMealPlans);
    }


    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal("weight gain");
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {

    }
}
