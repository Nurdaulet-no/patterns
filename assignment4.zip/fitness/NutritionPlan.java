package fitness;

import java.util.List;

public class NutritionPlan {
    private int dailyCaloricIntake;
    private int[] macronutrientRatios;
    private List<String> mealPlans;
    private String fitnessGoal;
    private List<String> dietaryRestrictions;
    public NutritionPlan(){

    }

    public NutritionPlan(int dailyCaloricIntake, int[] macronutrientRatios, List<String> mealPlans, String fitnessGoal, List<String> dietaryRestrictions) {
        this.dailyCaloricIntake = dailyCaloricIntake;
        this.macronutrientRatios = macronutrientRatios;
        this.mealPlans = mealPlans;
        this.fitnessGoal = fitnessGoal;
        this.dietaryRestrictions = dietaryRestrictions;
    }

    public int getDailyCaloricIntake() {
        return dailyCaloricIntake;
    }

    public int[] getMacronutrientRatios() {
        return macronutrientRatios;
    }

    public List<String> getMealPlans() {
        return mealPlans;
    }

    public String getFitnessGoal() {
        return fitnessGoal;
    }

    public List<String> getDietaryRestrictions() {
        return dietaryRestrictions;
    }

    public void setDailyCaloricIntake(int dailyCaloricIntake) {
        this.dailyCaloricIntake = dailyCaloricIntake;
    }

    public void setMacronutrientRatios(int[] macronutrientRatios) {
        this.macronutrientRatios = macronutrientRatios;
    }

    public void setMealPlans(List<String> mealPlans) {
        this.mealPlans = mealPlans;
    }

    public void setFitnessGoal(String fitnessGoal) {
        this.fitnessGoal = fitnessGoal;
    }

    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
        this.dietaryRestrictions = dietaryRestrictions;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < macronutrientRatios.length; i++) {
            sb.append(macronutrientRatios[i]);
            if (i < macronutrientRatios.length - 1) {
                sb.append("%, ");
            }
        }
        return sb.toString();
    }
}

