package fitness;

import java.util.List;

public abstract class NutritionPlanBuilder{
    protected NutritionPlan nutritionPlan;

    public abstract void setCaloricIntake(int caloricIntake);
    public abstract void setMacronutrientRatios(int carbohydrates, int proteins, int fats);
    public abstract void setMealPlans(List<String> mealPlans);
    public abstract void setFitnessGoal(String fitnessGoal);
    public abstract void setDietaryRestrictions(List<String> dietaryRestrictions);

    public NutritionPlan build() {
        return this.nutritionPlan;
    }
}
