package fitness;

import java.util.ArrayList;
import java.util.List;

public class WeightLossNutritionPlanBuilder extends NutritionPlanBuilder{
    @Override
    public void setCaloricIntake(int caloricIntake) {
        int weightLossCalories = caloricIntake - 300; // per day

        nutritionPlan.setDailyCaloricIntake(weightLossCalories);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        int newCarbohydrates = 10;
        int newProteins = 10;
        int newFats = 10;
        nutritionPlan.setMacronutrientRatios(new int[]{newCarbohydrates, newProteins, newFats});
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        List<String> newMealPlans = new ArrayList<>();
        newMealPlans.add("Lean protein sources with vegetables");
        newMealPlans.add("Healthy fats like avocados and nuts");
        newMealPlans.add("Complex carbohydrates in moderation");
        nutritionPlan.setMealPlans(newMealPlans);
    }

    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal("weight loss");
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
    }
}
