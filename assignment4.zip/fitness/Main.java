package fitness;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        NutritionPlanDirector director = new NutritionPlanDirector();
        NutritionPlanBuilder builder = null;

        String clientFitnessGoal = "weight gain";

        if(clientFitnessGoal.equalsIgnoreCase("weight loss")){
            builder = new WeightLossNutritionPlanBuilder();
        }else if(clientFitnessGoal.equalsIgnoreCase("weight gain")){
            builder = new WeightGainNutritionPlanBuilder();
        }else if(clientFitnessGoal.equalsIgnoreCase("maintenance")){
            builder = new MaintenanceNutritionPlanBuilder();
        }else{
            System.out.println("Invalid goal");
            System.exit(1);
        }

        director.setBuilder(builder);

        NutritionPlan nutritionPlan = director.createNutritionPlan();

        System.out.println("Nutrition Plan:");
        System.out.println("Fitness Goal: " + nutritionPlan.getFitnessGoal());
        System.out.println("Daily Caloric Intake: " + nutritionPlan.getDailyCaloricIntake());
        System.out.println("Macronutrient Ratios: " + Arrays.toString(nutritionPlan.getMacronutrientRatios()));
        System.out.println("Meal Plans: \n" + nutritionPlan.getMealPlans());
        System.out.println("Dietary Restrictions: " + nutritionPlan.getDietaryRestrictions());
    }
}
