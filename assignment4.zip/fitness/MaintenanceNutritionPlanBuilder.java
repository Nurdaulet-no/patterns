package fitness;

import java.util.ArrayList;
import java.util.List;

public class MaintenanceNutritionPlanBuilder extends NutritionPlanBuilder{
    @Override
    public void setCaloricIntake(int caloricIntake) {
        nutritionPlan.setDailyCaloricIntake(caloricIntake);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        int newCarbohydrates = 0;
        int newProteins = 0;
        int newFats = 0;
        nutritionPlan.setMacronutrientRatios(new int[]{newCarbohydrates, newProteins, newFats});
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        // Adjust meal plans for maintenance
        List<String> newMealPlans = new ArrayList<>();
        newMealPlans.add("Balanced meals with a variety of nutrients");
        newMealPlans.add("Include a mix of carbohydrates, proteins, and fats");
        newMealPlans.add("Focus on whole, unprocessed foods");
        newMealPlans.add("Portion control to maintain calorie balance");
        newMealPlans.add("Regular meals and snacks throughout the day");
        nutritionPlan.setMealPlans(newMealPlans);
    }


    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal("maintenance");
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {

    }
}
