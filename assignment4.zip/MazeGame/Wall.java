package MazeGame;

public class Wall{

}