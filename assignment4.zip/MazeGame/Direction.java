package MazeGame;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
