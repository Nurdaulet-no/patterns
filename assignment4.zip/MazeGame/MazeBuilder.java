package MazeGame;

public interface MazeBuilder {
    void buildRooms(Maze maze);
    void buildWalls(Room room);
    void buildDoor(Room room1, Room room2, Direction direction);
}
