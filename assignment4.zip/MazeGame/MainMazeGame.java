package MazeGame;

public class MainMazeGame {
    public static void main(String[] args) {
        createMaze(new SimpleMazeBuilder());
        createMaze(new ComplexMazeBuilder());
    }

    private static void createMaze(MazeBuilder builder) {
        Maze maze = new Maze();
        builder.buildRooms(maze);
        for (Room room : maze.rooms.values()) {
            builder.buildWalls(room);
        }
        builder.buildDoor(maze.roomNo(1), maze.roomNo(2), Direction.SOUTH);
    }
}

