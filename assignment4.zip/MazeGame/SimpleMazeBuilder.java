package MazeGame;

public class SimpleMazeBuilder implements MazeBuilder {
    @Override
    public void buildRooms(Maze maze) {
        Room r1 = new Room(1);
        Room r2 = new Room(2);
        maze.addRoom(r1);
        maze.addRoom(r2);
    }

    @Override
    public void buildWalls(Room room) {
        room.setSide(Direction.NORTH, newWall());
        room.setSide(Direction.EAST, newWall());
        room.setSide(Direction.SOUTH, newWall());
        room.setSide(Direction.WEST, newWall());
    }

    @Override
    public void buildDoor(Room room1, Room room2, Direction direction) {
        // SimpleMazeBuilder doesn't require doors between rooms
    }

    private Wall newWall() {
        return new Wall();
    }
}
