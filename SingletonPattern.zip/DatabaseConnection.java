import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

public class DatabaseConnection {
    private static volatile DatabaseConnection instance;
    private String hostname;
    private String username;
    private String password;
    private String databaseName;

    private DatabaseConnection(){
        loadConfiguration();
    }
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }
    public void executeQuery(String query) {
        // Execute SQL query
        System.out.println("Executing query: " + query);
        // Simulated execution
        System.out.println("Query executed successfully.");
    }
    public String getHostname() {
        return hostname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getDatabaseName() {
        return databaseName;
    }
    private void loadConfiguration(){
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            ConfigData configData = objectMapper.readValue(new File("database_config.json"), ConfigData.class);

            this.hostname = configData.getHostname();
            this.username = configData.getUsername();
            this.password = configData.getPassword();
            this.databaseName = configData.getDatabaseName();
        }catch (IOException e){
            System.out.println("Failed to load configuration: " + e.getMessage());
        }
    }

    static class ConfigData{
        private String hostname;
        private String username;
        private String password;
        private String databaseName;
        public String getHostname() {
            return hostname;
        }
        public String getUsername() {
            return username;
        }
        public String getPassword() {
            return password;
        }
        public String getDatabaseName() {
            return databaseName;
        }
    }
}
