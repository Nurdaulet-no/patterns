public class Test {
    public static void main(String[] args) {
        DatabaseConnection connection = DatabaseConnection.getInstance();

        System.out.println("Hostname: " + connection.getHostname());
        System.out.println("Username: " + connection.getUsername());
        System.out.println("Password: " + connection.getPassword());
        System.out.println("Database name: " + connection.getDatabaseName());

        connection.executeQuery("SELECT * FROM table_name");
    }
}
